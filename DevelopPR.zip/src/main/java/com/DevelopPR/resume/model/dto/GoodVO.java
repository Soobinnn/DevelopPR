package com.DevelopPR.resume.model.dto;

public class GoodVO {
	private String good_nick;
	private String good_email;
	
	public String getGood_nick() {
		return good_nick;
	}
	public void setGood_nick(String good_nick) {
		this.good_nick = good_nick;
	}
	public String getGood_email() {
		return good_email;
	}
	public void setGood_email(String good_email) {
		this.good_email = good_email;
	}
	
}
